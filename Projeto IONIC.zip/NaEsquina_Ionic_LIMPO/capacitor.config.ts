import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.naesquina.app',
  appName: 'Na Esquina',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  }
};

export default config;
