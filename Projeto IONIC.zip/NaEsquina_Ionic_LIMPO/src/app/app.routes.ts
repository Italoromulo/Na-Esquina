import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'loading',
    pathMatch: 'full'
  },
  {
    path: 'loading',
    loadComponent: () => import('./loading/loading.page').then(m => m.LoadingPage)
  },
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then(m => m.HomePage)
  },
  {
    path: 'membros',
    loadComponent: () => import('./membros/membros.page').then(m => m.MembrosPage)
  }
];
