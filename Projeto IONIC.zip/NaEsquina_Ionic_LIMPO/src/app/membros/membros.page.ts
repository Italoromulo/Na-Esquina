import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { IonContent } from '@ionic/angular/standalone';

@Component({
  selector: 'app-membros',
  templateUrl: './membros.page.html',
  styleUrls: ['./membros.page.scss'],
  standalone: true,
  imports: [CommonModule, RouterLink, IonContent]
})
export class MembrosPage {
  membros = [
    { nome: 'Italo Rômulo da Conceição', funcao: 'Organização do projeto e desenvolvimento.' },
    { nome: 'Yan Oliveira de Souza Martins', funcao: 'Interface, documentação e testes.' },
    { nome: 'João Pedro Specie', funcao: 'Navegação e estrutura técnica.' },
    { nome: 'Victor de Lucena Justa', funcao: 'Testes, mapa e validação.' },
    { nome: 'Luiz Guilherme Dias Gomes', funcao: 'Layout, feed e ajustes visuais.' },
    { nome: 'Diogo Bello', funcao: 'Documentação e apoio geral.' }
  ];
}
