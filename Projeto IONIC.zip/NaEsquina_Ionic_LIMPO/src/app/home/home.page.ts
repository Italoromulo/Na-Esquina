import { Component, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { IonContent } from '@ionic/angular/standalone';
import { Geolocation } from '@capacitor/geolocation';

interface Restaurant {
  id: number;
  name: string;
  cuisine: string;
  rating: number;
  reviews: number;
  distance: string;
  status: 'open' | 'closed';
  category: string;
  logo: string;
  lat: number;
  lng: number;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, IonContent]
})
export class HomePage implements AfterViewInit {
  searchTerm = '';
  currentCategory = 'all';
  selectedId: number | null = null;

  restaurants: Restaurant[] = [
    { id: 1, name: 'Burgers do João', cuisine: 'Hambúrguer Artesanal', rating: 4.8, reviews: 234, distance: '0.3 km', status: 'open', category: 'burguer', logo: '🍔', lat: 30, lng: 40 },
    { id: 2, name: 'Pizza da Maria', cuisine: 'Pizza Italiana', rating: 4.6, reviews: 189, distance: '0.5 km', status: 'open', category: 'pizza', logo: '🍕', lat: 50, lng: 60 },
    { id: 3, name: 'Pastel & Cia', cuisine: 'Salgados Fritos', rating: 4.3, reviews: 156, distance: '0.8 km', status: 'open', category: 'salgados', logo: '🥟', lat: 40, lng: 30 },
    { id: 4, name: 'Doces Sonhos', cuisine: 'Bolos e Tortas', rating: 4.9, reviews: 312, distance: '1.2 km', status: 'open', category: 'doces', logo: '🍰', lat: 60, lng: 50 },
    { id: 5, name: 'Taco Loco', cuisine: 'Comida Mexicana', rating: 4.7, reviews: 201, distance: '1.5 km', status: 'open', category: 'burguer', logo: '🌮', lat: 70, lng: 35 },
    { id: 6, name: 'Açaí do Norte', cuisine: 'Açaí e Sobremesas', rating: 4.4, reviews: 145, distance: '0.9 km', status: 'open', category: 'doces', logo: '🥤', lat: 55, lng: 45 },
    { id: 7, name: 'Coxinha Gold', cuisine: 'Salgados Assados', rating: 4.2, reviews: 87, distance: '2.1 km', status: 'closed', category: 'salgados', logo: '🥐', lat: 25, lng: 55 }
  ];

  categories = [
    { key: 'all', icon: '🍽️', label: 'Todos' },
    { key: 'burguer', icon: '🍔', label: 'Burgers' },
    { key: 'pizza', icon: '🍕', label: 'Pizzas' },
    { key: 'salgados', icon: '🥟', label: 'Salgados' },
    { key: 'doces', icon: '🍰', label: 'Doces' }
  ];

  ngAfterViewInit() {}

  get filteredRestaurants(): Restaurant[] {
    return this.restaurants.filter(r => {
      const categoryMatch = this.currentCategory === 'all' || r.category === this.currentCategory;
      const search = this.searchTerm.trim().toLowerCase();
      const searchMatch = !search || r.name.toLowerCase().includes(search) || r.cuisine.toLowerCase().includes(search);
      return categoryMatch && searchMatch;
    });
  }

  selectCategory(category: string) {
    this.currentCategory = category;
  }

  selectRestaurant(id: number) {
    this.selectedId = id;
  }

  async updateLocation() {
    try {
      await Geolocation.requestPermissions();
      const position = await Geolocation.getCurrentPosition();
      alert(`Localização atualizada: ${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`);
    } catch {
      alert('Não foi possível obter sua localização.');
    }
  }
}
